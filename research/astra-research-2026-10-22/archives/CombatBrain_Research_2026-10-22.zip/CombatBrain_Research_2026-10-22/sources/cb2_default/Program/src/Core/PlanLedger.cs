using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace CombatBrain2.Core
{
    // 计划生命周期：建立、保持、失效处置。
    // 计划自己在条件不成立、任务超时、写令失败、命令不生效、
    // 命令被覆盖或编队失去资格时失效；失效后一次性处置全部开放任务。
    internal sealed class PlanLedger
    {
        private BattlePlan _current;
        private int _planCount;
        private int _invalidations;
        private string _failedCoordinationState = "";
        // 2026-10-18 裁定：同一失败分配最多允许一次重新执行。额度只在计划真正建成时消耗，
        // 时间、输入编号、坐标抖动、轮询次数与新 Plan ID 都不能把它刷新回来。
        private int _failedCoordinationRetries;
        internal bool CoordinationCreationBlocked { get; private set; }
        internal bool CoordinationRetryConsumed { get; private set; }
        private readonly Dictionary<string, int> _invalidationReasons =
            new Dictionary<string, int>(StringComparer.Ordinal);

        internal BattlePlan Current { get { return _current; } }
        internal bool HasPlan { get { return _current != null && !_current.IsClosed; } }
        internal int PlanCount { get { return _planCount; } }
        internal int Invalidations { get { return _invalidations; } }

        internal int CountOf(PlanInvalidReason reason)
        {
            int n;
            return _invalidationReasons.TryGetValue(reason.ToString(), out n) ? n : 0;
        }

        // 条件未变且计划仍开放时可继续沿用旧计划。
        // 继续判定用更窄的继续门槛与兵力线，不用创建时的一次布尔相等（脚本 §4.5）。
        internal bool CanContinue(PlanConditions conditions, double now)
        {
            if (_current == null || _current.IsClosed) return false;
            if (conditions == null) return false;
            return conditions.CanContinueAs(_current);
        }

        internal BattlePlan Create(BattleState state, double now)
        {
            _planCount++;
            var id = "plan-" + _planCount.ToString(CultureInfo.InvariantCulture);
            var plan = PlanBuilder.Build(state, id, now);
            if (plan != null) _current = plan;
            return plan;
        }

        // P2 路径：与 P1 的 Create 互斥，同一时刻只有一条路径在跑（派单 §7）。
        internal void RememberFailedCoordination(BattleState state)
        {
            if (!CoordinationDriver.IsCoordinationPlan(_current) || state == null) return;
            var key = CoordinationStateKey(state);
            // 同一失败分配只记一次：已经消耗过额度就不再回填。
            if (string.Equals(key, _failedCoordinationState, StringComparison.Ordinal)) return;
            _failedCoordinationState = key;
            _failedCoordinationRetries = 1;
        }

        // Time, coordinates and input IDs must not turn the same failed assignment into a new opportunity.
        private static string CoordinationStateKey(BattleState state)
        {
            if (state == null) return "";
            var c = PlanConditions.From(state);
            var key = new StringBuilder(state.MissionKey ?? "");
            key.Append('|').Append(c.RangedAdvantageHolds).Append('|').Append(c.RangedDisadvantageHolds)
                .Append('|').Append(c.StrengthWithinTolerance).Append('|').Append(c.StrengthCritical)
                .Append('|').Append(c.CoordinationCanContinue);
            foreach (var side in new[] { state.MyFormations, state.EnemyFormations })
            {
                var records = new List<FormationRecord>(side);
                records.Sort((a, b) => string.CompareOrdinal(a.Key(), b.Key()));
                key.Append("/side");
                foreach (var r in records)
                    key.Append('|').Append(r.Key()).Append(':').Append(r.ObjectIdentity)
                        .Append(':').Append(r.FormationClass).Append(':').Append(r.MemberDigest)
                        .Append(':').Append(r.ActiveMemberCount).Append(':').Append(r.UnitCount)
                        .Append(':').Append(r.HasActiveCenter).Append(':').Append(r.IsAiControlled)
                        .Append(':').Append(r.IsPlayerControlled).Append(':').Append(r.IsPlayerTeam);
            }
            return key.ToString();
        }

        internal BattlePlan CreateCoordination(BattleState state, double now)
        {
            CoordinationRetryConsumed = false;
            // 只有失败分配完全相同的状态才受抑制；前提真正变化（对象、资格、兵力或
            // 成员身份改变）会得到不同的键，按既定重评规则直接允许新建。
            bool sameFailedAssignment = state != null && _failedCoordinationState.Length > 0 &&
                string.Equals(_failedCoordinationState, CoordinationStateKey(state), StringComparison.Ordinal);
            CoordinationCreationBlocked = sameFailedAssignment && _failedCoordinationRetries <= 0;
            if (CoordinationCreationBlocked) return null;
            _planCount++;
            var id = "plan-" + _planCount.ToString(CultureInfo.InvariantCulture);
            var plan = PlanBuilder.BuildCoordination(state, id, now);
            if (plan != null)
            {
                _current = plan;
                // 建成才消耗额度：构建失败不占这次重试预算，也不复活旧任务。
                if (sameFailedAssignment)
                {
                    _failedCoordinationRetries--;
                    CoordinationRetryConsumed = true;
                }
            }
            return plan;
        }

        // 分配改变必须增版本：旧版本任务不得写令，也不得取消或清掉新版本的槽位。
        internal static void BumpRevision(BattlePlan plan)
        {
            if (plan == null) return;
            plan.Revision++;
        }

        // P3：继任计划由结果反馈决定生成，不在条件输入路径上。
        // 生成即占号，构建失败不回退计数——计划身份不能重复。
        internal string NextPlanId()
        {
            _planCount++;
            return "plan-" + _planCount.ToString(CultureInfo.InvariantCulture);
        }

        internal void Adopt(BattlePlan plan)
        {
            if (plan == null) return;
            _current = plan;
        }

        internal void Invalidate(PlanInvalidReason reason, string detail, double now)
        {
            if (_current == null || _current.IsClosed) return;
            _current.IsClosed = true;
            _current.ClosedAt = now;
            _current.InvalidReason = reason;
            _current.InvalidDetail = detail ?? "";
            _invalidations++;
            var key = reason.ToString();
            int n;
            _invalidationReasons.TryGetValue(key, out n);
            _invalidationReasons[key] = n + 1;
        }

        internal void ClearMission()
        {
            _current = null;
            _planCount = 0;
            _invalidations = 0;
            _failedCoordinationState = "";
            _failedCoordinationRetries = 0;
            CoordinationRetryConsumed = false;
            CoordinationCreationBlocked = false;
            _invalidationReasons.Clear();
        }
    }
}
