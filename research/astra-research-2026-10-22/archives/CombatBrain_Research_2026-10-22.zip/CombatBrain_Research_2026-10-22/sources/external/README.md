# 外部原始资料

访问日：2026-10-22（Asia/Shanghai）。用途是核读、定位和研究复核，不表示取得代码复制许可。

- `manifest.json`：固定提交、原始 URL、下载 PDF SHA-256 与大小。
- `RBM/`：公开仓库的 sparse clone。提交 `7f9069b6e111c7ce124f07545f0edef8202042bf`，只检出 AI、Campaign 和文档相关目录；根目录没有 README/LICENSE，完整树文件名检索也未找到 LICENSE/COPYING/COPYRIGHT。
- `killzone2.pdf` / `horizon.pdf`：Guerrilla 官方演讲；文字层遗漏了多数幻灯片文字，`kz_crop_*.png` 与 `horizon_*_contact.png` 用于核读正文。它们是来源呈现，不是本研究生成的设计。
- `pgs.pdf` / `pgs.txt`：Churchill 作者站原论文及文字提取。
- `cmab.pdf` / `cmab.txt`：Ontañón arXiv 原论文及文字提取。
- `temporal.pdf` / `temporal_page_*.png`：Dechter 作者 UCI 站扫描论文及核读的 §3 页图；全文 35 页，无文字层。
- MRTA 原论文通过 web 工具读取 SFU 镜像正文，下载失败，未伪造本地 PDF；可靠定位与阅读边界在 `../../evidence/external_research.md`。

下载曾出现 GitHub API 403 rate limit、Stanford connection refused、部分大学站 SSL/超时。RBM 改用公开 git clone；MRTA 改读原论文大学镜像；UCI 后续完整下载成功且由 PDF reader 确认为 35 页。研究不依据失败请求内容。

本次没有复制/改造任何第三方算法源码进入原型。对 RBM 无明确授权，因此建议仅独立转译机制。其他论文/演讲的公开阅读/下载也不是源码复用许可。

复核 RBM 身份与许可文件路径：

```bash
git -C RBM rev-parse HEAD
git -C RBM log -1 --format='%cI %s'
git -C RBM ls-tree -r --name-only HEAD | rg -i 'license|copying|copyright'
```

最后一个命令无匹配时退出码为 1，表示此名称检索无命中，不是对所有潜在授权文本的法律结论。AI `Readme.txt` 已读，内容为开发文档入口，无许可条款。
